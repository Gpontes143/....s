function mudapubli (foto) {
    document.getElementById("publi").src = foto;
}